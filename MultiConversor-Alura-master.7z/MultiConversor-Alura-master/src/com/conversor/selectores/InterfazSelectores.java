package com.conversor.selectores;
public interface InterfazSelectores{
	
	String[] conversiones=null;
	
	void OpcionesConversor();	

}
